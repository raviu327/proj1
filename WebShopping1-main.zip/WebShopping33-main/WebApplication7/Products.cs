﻿namespace WebApplication7
{
    public class Products
    {

        public int product_id { get; set; }
        public string product_name { get; set; }
        public string price { get; set; }
       
        public string product_description { get; set; }
        

    }
}
